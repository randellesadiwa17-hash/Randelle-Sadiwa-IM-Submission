﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LIBRARY_SYSTEM_CRUD_IM
{
    public partial class Form2 : Form
    {
        string connectionString = "server=localhost;database=library_db;uid=root;pwd=admin123;";
        public Form2()
        {
            InitializeComponent();
        }

        private void pbSearch_Click(object sender, EventArgs e)
        {
            string keyword = txtSearch.Text.Trim();

            if (string.IsNullOrWhiteSpace(keyword))
            {
                MessageBox.Show("Please enter a keyword to search.", "Search", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            using (MySqlConnection conn = new MySqlConnection(connectionString))
            {
                try
                {
                    conn.Open();
                    string sql = @"SELECT * FROM books 
                           WHERE title LIKE @keyword 
                              OR author LIKE @keyword 
                              OR year LIKE @keyword
                              OR copies LIKE @keyword";

                    MySqlCommand cmd = new MySqlCommand(sql, conn);
                    cmd.Parameters.AddWithValue("@keyword", "%" + keyword + "%");

                    MySqlDataAdapter da = new MySqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    da.Fill(dt);

                    if (dt.Rows.Count > 0)
                    {
                        dgvBooks.DataSource = dt;
                    }
                    else
                    {
                        dgvBooks.DataSource = null;
                        dgvBooks.Rows.Clear();
                        MessageBox.Show("No records found.", "Search Result", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error during search: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            dgvBooks.DataSource = null;
            dgvBooks.Rows.Clear();
            dgvBooks.Refresh();
            txtSearch.Clear();
        }

        private void label2_Click(object sender, EventArgs e)
        {
            Form3 form = new Form3();
            form.ShowDialog();
        }
    }
}
